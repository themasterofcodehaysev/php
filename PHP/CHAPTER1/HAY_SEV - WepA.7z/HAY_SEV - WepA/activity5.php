<ul>
    <?php
    // Instructions: replace XXXXXXXXX by a code to display the value of $index from 0 to 4
    for ($index = 0; $index < 5; $index++) :
    ?>
        <li> current index is <?php echo $index ?> </li>

    <?php
    endfor
    ?>

</ul>