before php tag
<?php
    // Just execute this file and understand What happens if there is text outside of php tags ?
    echo "Inside first php tag";
?>

between php tags

<?php 
    echo "Inside second php tag";
?>

after php tag